package edu.fje.daw2dam2;

/**
 * Classe que representa un Tambor
 * @author sergi.grau@fje.edu
 * @version 1.0 19.11.2015
 */
public class Tambor extends Percusio {
}
