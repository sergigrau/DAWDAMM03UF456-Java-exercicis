package edu.fje.daw2dam2;

/**
 * Classe que representa una percursió
 * @author sergi.grau@fje.edu
 * @version 1.0 19.11.2015
 */
public abstract class Percusio extends Instrument {
}
