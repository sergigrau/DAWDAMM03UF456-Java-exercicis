package edu.fje.daw2dam2;

/**
 * Classe que representa uns Platets
 * @author sergi.grau@fje.edu
 * @version 1.0 19.11.2015
 */
public class Platets extends Percusio {

    private String so;

    public String getSo() {
        return so;
    }

    public void setSo(String so) {
        this.so = so;
    }
}
