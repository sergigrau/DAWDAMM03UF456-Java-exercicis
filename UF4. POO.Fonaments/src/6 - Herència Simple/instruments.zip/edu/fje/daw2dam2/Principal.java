package edu.fje.daw2dam2;

/**
 * Created by MBP on 19/11/15.
 */
public class Principal {

    public static void main (String args){
        Instrument[] instruments = new Instrument[4];
        instruments[0] = new Vent();
        instruments[1] = new Corda();
        instruments[2] = new Platets();
        instruments[3] = new Tambor();

        for(Instrument instrument: instruments){
            instrument.tocar();
        }

    }
}
