package edu.fje.daw2dam2;

/**
 * Classe que representa un instrument
 * @author sergi.grau@fje.edu
 * @version 1.0 19.11.2015
 */
public abstract class Instrument {
    private boolean afinat;
    private int nivell=2;

    public void tocar() {
        System.out.println("has tocat un instrument de "+ getClass().getName());
    }

    public int queNivell(){
        return nivell;
    }

    public void afinar(){
        afinat=true;
    }
}
