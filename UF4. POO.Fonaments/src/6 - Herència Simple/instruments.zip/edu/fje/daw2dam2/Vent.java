package edu.fje.daw2dam2;

/**
 * Classe que representa un instrument de vent
 * @author sergi.grau@fje.edu
 * @version 1.0 19.11.2015
 */
public class Vent extends Instrument {

}
