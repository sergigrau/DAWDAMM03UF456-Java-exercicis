package edu.fje.daw2dam2;

/**
 * Classe que representa una corda
 * @author sergi.grau@fje.edu
 * @version 1.0 19.11.2015
 */
public class Corda extends Instrument {

}
